import { TotalAmount } from './total-amount';

describe('TotalAmount', () => {
  it('should create an instance', () => {
    expect(new TotalAmount()).toBeTruthy();
  });
});
