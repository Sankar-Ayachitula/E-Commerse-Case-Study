export class Product {
    id:number
    name:string
    description:string
    cost:number
    constructor(){
        this.id=0
        this.name=""
        this.description=""
        this.cost=0
    }

}
