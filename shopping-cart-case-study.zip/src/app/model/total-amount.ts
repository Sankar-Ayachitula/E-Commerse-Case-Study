export class TotalAmount {
    amount:number
    constructor(){
        this.amount=0
    }
}
